# 转接外呼 (Transfer Callout) 运维手册

> 服务端口：8098 | 最后更新：2026-04-13

---

## 1. 功能概述

转接外呼是一个独立呼叫流，通过 FreeSWITCH 拨号计划 `"2000"` 前缀路由触发。呼叫发起前经过 6 步校验管道，任一不通过则拦截呼叫。

### 校验管道

```
主叫鉴权 → 时段控制 → 被叫黑名单 → 被叫白名单(放行跳过后续) → 客户余额 → 被叫频次
```

| 步骤 | 校验项 | 不通过结果码 | 说明 |
|------|--------|-------------|------|
| 1 | 主叫鉴权 | 1 | 主叫号码不在白名单中 |
| 2 | 时段控制 | 2 | 当前时间在禁止呼出时段内 |
| 3 | 被叫黑名单 | 3 | 被叫号码在黑名单中 |
| 4 | 被叫白名单 | 0 | 白名单命中则直接放行，跳过 5-6 |
| 5 | 客户余额 | 4 | 仅预付费客户检查，后付费直接放行 |
| 6 | 被叫频次 | 5 | 超过每小时呼叫上限 |

### 校验不通过语音提示

校验不通过时，系统会播放对应语音提示后挂断。

| Code | 说明 | 语音文件 | TTS 文本 |
|------|------|----------|----------|
| 0 | 通过 | - | - |
| 1 | 主叫号码鉴权不通过 | `transfer_caller_auth_fail.wav` | 对不起，您的主叫号码未授权，无法拨打此电话。 |
| 2 | 禁止呼出时段 | `transfer_forbidden_time.wav` | 对不起，现在是禁止呼出时段，请稍后再拨。 |
| 3 | 被叫号码黑名单 | `transfer_blacklist.wav` | 对不起，您拨打的号码在黑名单中，无法接通。 |
| 4 | 余额不足 | `transfer_no_balance.wav` | 对不起，您的账户余额不足，请及时充值。 |
| 5 | 被叫频次超限 | `transfer_freq_limit.wav` | 对不起，您拨打的号码呼叫频次超限，请稍后再拨。 |

**运维要点**：
- 语音文件需部署在 FreeSWITCH 服务器上的语音播放目录中（具体路径见部署配置）
- 如需自定义提示音，替换对应 `.wav` 文件即可，文件名不可更改
- `.wav` 文件格式要求：8000Hz 采样率、16bit、单声道（FreeSWITCH 标准）

---

## 2. 部署与启动

### 2.1 建表

首次部署执行建表脚本：

```bash
mysql -u root -p < src/main/resources/sql/init_transfer_callout.sql
```

共 5 张表：`call_customer`、`call_caller_auth`、`call_forbidden_time`、`call_called_number_list`、`fs_cdr`。

#### call_customer 客户信息表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT AUTO_INCREMENT | 主键 |
| account | VARCHAR(64) | 客户账号（唯一） |
| name | VARCHAR(128) | 客户名称 |
| balance | DECIMAL(12,4) | 余额 |
| unit_price | DECIMAL(10,4) | 每分钟单价 |
| pay_type | TINYINT | 0=预付费，1=后付费 |
| max_calls_per_hour | INT | 每小时最大呼叫次数，0=不限制 |
| status | TINYINT | 0=禁用，1=启用 |
| create_time | DATETIME | 创建时间 |
| update_time | DATETIME | 更新时间 |

唯一约束：`uk_account(account)`

#### call_caller_auth 主叫号码鉴权白名单表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT AUTO_INCREMENT | 主键 |
| customer_acc | VARCHAR(64) | 客户账号 |
| caller_number | VARCHAR(64) | 主叫号码 |
| status | TINYINT | 0=禁用，1=启用 |
| create_time | DATETIME | 创建时间 |
| update_time | DATETIME | 更新时间 |

唯一约束：`uk_customer_caller(customer_acc, caller_number)`

#### call_forbidden_time 呼叫禁止时段表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT AUTO_INCREMENT | 主键 |
| customer_acc | VARCHAR(64) | 客户账号 |
| period_name | VARCHAR(128) | 时段名称 |
| start_time | TIME | 开始时间 |
| end_time | TIME | 结束时间 |
| status | TINYINT | 0=禁用，1=启用 |
| create_time | DATETIME | 创建时间 |
| update_time | DATETIME | 更新时间 |

索引：`idx_customer_acc(customer_acc)`

#### call_called_number_list 被叫号码黑白名单表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT AUTO_INCREMENT | 主键 |
| customer_acc | VARCHAR(64) | 客户账号 |
| number | VARCHAR(64) | 号码或前缀 |
| match_type | TINYINT | 1=精确匹配，2=前缀匹配 |
| list_type | TINYINT | 1=黑名单，2=白名单 |
| status | TINYINT | 0=禁用，1=启用（默认 1） |
| create_time | DATETIME | 创建时间 |
| update_time | DATETIME | 更新时间 |

唯一约束：`uk_cust_num_type(customer_acc, number, list_type)`

#### fs_cdr 话单表（按月分区）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT AUTO_INCREMENT | 主键（与 start_stamp 组合主键） |
| direction | VARCHAR(16) | 呼叫方向（inbound/outbound） |
| sip_local_network_addr | VARCHAR(32) | 本地 SIP 网络地址 |
| sip_network_ip | VARCHAR(32) | 远端 SIP 网络 IP |
| caller_id_number | VARCHAR(64) | 主叫号码 |
| destination_number | VARCHAR(64) | 被叫号码 |
| start_stamp | DATETIME | 呼叫开始时间 |
| answer_stamp | DATETIME | 应答时间 |
| end_stamp | DATETIME | 结束时间 |
| duration | INT | 总时长（秒） |
| answersec | INT | 应答时长（秒） |
| billsec | INT | 计费时长（秒） |
| hangup_cause | VARCHAR(64) | 挂断原因 |
| uuid | VARCHAR(64) | 通道 UUID |
| read_codec | VARCHAR(64) | 读取编解码 |
| write_codec | VARCHAR(64) | 写入编解码 |
| customer_acc | VARCHAR(64) | 客户账号 |
| income_fee | DECIMAL(10,4) | 计费金额 |
| bridge_uuid | VARCHAR(64) | 桥接 UUID |
| aleg_uuid | VARCHAR(64) | A LEG UUID |

分区方式：`PARTITION BY RANGE (to_days(start_stamp))`，按月自动分区。

索引：`start_stamp`、`caller_id_number`、`destination_number`、`uuid`

### 2.2 启动服务

```bash
java -jar fs-esl-springboot-starter-callout-1.0.0.RELEASE.jar
```

启动时自动执行：
- `CallerAuthSyncService` — 从 DB 全量加载主叫鉴权白名单到 Redis
- `ForbiddenTimeSyncService` — 从 DB 全量加载禁止时段到 Redis
- `CalledNumberListService` — 从 DB 全量加载被叫黑白名单到 Redis（`@PostConstruct`）

### 2.3 依赖

| 组件 | 说明 |
|------|------|
| MySQL | 主从架构，读写分离 |
| Redis | 校验数据缓存 + 频次计数器 |
| FreeSWITCH | ESL 事件源 + mod_format_cdr 话单推送 |

---

## 3. 日常运维操作

### 3.1 客户管理

#### 新增客户

```bash
curl -X POST http://localhost:8098/transfer/customer/add \
  -H "Content-Type: application/json" \
  -d '{
    "account": "cust001",
    "name": "客户A",
    "balance": 1000.00,
    "unitPrice": 0.10,
    "payType": 0,
    "maxCallsPerHour": 100,
    "status": 1
  }'
```

**字段说明**：
| 字段 | 说明 | 取值 |
|------|------|------|
| account | 客户账号（唯一） | 字符串 |
| balance | 余额 | DECIMAL，后付费可设 0 |
| unitPrice | 每分钟单价 | DECIMAL |
| payType | 付费类型 | 0=预付，1=后付 |
| maxCallsPerHour | 每小时最大呼叫次数 | 0=不限制 |
| status | 状态 | 0=禁用，1=启用 |

#### 查询客户

```bash
curl "http://localhost:8098/transfer/customer/get?account=cust001"
```

#### 客户列表

```bash
curl "http://localhost:8098/transfer/customer/list"
```

#### 分页查询

```bash
curl "http://localhost:8098/transfer/customer/page?page=1&pageSize=10&account=cust001&status=1"
```

返回格式：`{data: [], total, page, pageSize}`。支持 account、name、status 筛选。

#### 更新客户

```bash
curl -X PUT http://localhost:8098/transfer/customer/update \
  -H "Content-Type: application/json" \
  -d '{
    "id": 1,
    "account": "cust001",
    "name": "客户A",
    "balance": 500.00,
    "unitPrice": 0.10,
    "payType": 0,
    "maxCallsPerHour": 100,
    "status": 1
  }'
```

#### 删除客户

```bash
curl -X DELETE "http://localhost:8098/transfer/customer/delete?id=1"
```

#### 检查余额

```bash
curl "http://localhost:8098/transfer/customer/balance?account=cust001"
```

返回 `true`/`false`。后付费客户始终返回 `true`。

#### 充值余额

直接通过 SQL 操作：

```sql
UPDATE call_customer SET balance = balance + 500.00 WHERE account = 'cust001';
```

---

### 3.2 主叫号码鉴权白名单

管理哪些主叫号码可以使用转接外呼功能。数据存储在 DB + Redis。

#### 添加白名单

```bash
curl -X POST http://localhost:8098/transfer/auth/add \
  -H "Content-Type: application/json" \
  -d '{
    "customerAcc": "cust001",
    "callerNumber": "13800138000",
    "status": 1
  }'
```

添加后需手动同步到 Redis（见下方同步操作）。

#### 查询白名单

```bash
curl "http://localhost:8098/transfer/auth/list?customerAcc=cust001"
```

#### 分页查询

```bash
curl "http://localhost:8098/transfer/auth/page?page=1&pageSize=10&customerAcc=cust001&status=1"
```

支持 customerAcc、callerNumber、status 筛选。

#### 删除白名单

```bash
curl -X DELETE "http://localhost:8098/transfer/auth/delete?id=1"
```

#### 同步到 Redis

```bash
# 全量同步所有客户
curl -X POST http://localhost:8098/transfer/auth/sync

# 按客户同步
curl -X POST "http://localhost:8098/transfer/auth/sync/customer?customerAcc=cust001"
```

**注意**：增删改白名单后，必须执行同步操作，否则 Redis 中数据不会更新。

#### 检查鉴权

```bash
curl "http://localhost:8098/transfer/auth/check?customerAcc=cust001&callerNumber=13800138000"
```

---

### 3.3 被叫号码黑白名单

数据存储在 DB + Redis 双写。推荐使用 **DB 持久化接口**（自动同步 Redis），旧版纯 Redis 接口仍可使用。

#### 3.3.1 DB 持久化接口（推荐）

通过 `call_called_number_list` 表持久化，增删改时自动同步 Redis。

##### 分页查询

```bash
curl "http://localhost:8098/transfer/numberlist/page?page=1&pageSize=10&customerAcc=cust001&listType=1"
```

| 参数 | 说明 | 取值 |
|------|------|------|
| customerAcc | 客户账号（可选） | 字符串 |
| listType | 名单类型（可选） | 1=黑名单，2=白名单 |
| page | 页码（默认 1） | 整数 |
| pageSize | 每页条数（默认 10） | 整数 |

返回格式：`{data: [], total, page, pageSize}`

##### 新增记录

```bash
curl -X POST http://localhost:8098/transfer/numberlist/record/add \
  -H "Content-Type: application/json" \
  -d '{
    "customerAcc": "cust001",
    "number": "10086",
    "matchType": 1,
    "listType": 1,
    "status": 1
  }'
```

| 字段 | 说明 | 取值 |
|------|------|------|
| customerAcc | 客户账号 | 字符串 |
| number | 号码或前缀 | 字符串 |
| matchType | 匹配类型 | 1=精确匹配，2=前缀匹配 |
| listType | 名单类型 | 1=黑名单，2=白名单 |
| status | 状态 | 0=禁用，1=启用 |

插入 DB 后自动同步到 Redis（status=1 时生效）。

##### 更新记录

```bash
curl -X PUT http://localhost:8098/transfer/numberlist/update \
  -H "Content-Type: application/json" \
  -d '{
    "id": 1,
    "number": "10087",
    "matchType": 1,
    "status": 1
  }'
```

更新 DB 后自动重建该客户的 Redis 数据。

##### 删除记录

```bash
curl -X DELETE "http://localhost:8098/transfer/numberlist/delete/1"
```

从 DB 删除后自动从 Redis 移除。

##### 同步到 Redis

```bash
# 全量同步：从 DB 读取所有启用记录，重建 Redis
curl -X POST http://localhost:8098/transfer/numberlist/sync

# 按客户同步
curl -X POST "http://localhost:8098/transfer/numberlist/sync/customer?customerAcc=cust001"
```

#### 3.3.2 旧版纯 Redis 接口

操作即时生效，无 DB 持久化，服务重启后丢失。

##### 黑名单 — 精准匹配

```bash
# 添加
curl -X POST "http://localhost:8098/transfer/numberlist/black/exact/add?customerAcc=cust001&number=10086"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/black/exact/remove?customerAcc=cust001&number=10086"
```

##### 黑名单 — 前缀匹配

```bash
# 添加：拦截所有 400 开头的号码
curl -X POST "http://localhost:8098/transfer/numberlist/black/prefix/add?customerAcc=cust001&prefix=400"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/black/prefix/remove?customerAcc=cust001&prefix=400"
```

##### 白名单 — 精准匹配

```bash
# 添加
curl -X POST "http://localhost:8098/transfer/numberlist/white/exact/add?customerAcc=cust001&number=10010"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/white/exact/remove?customerAcc=cust001&number=10010"
```

##### 白名单 — 前缀匹配

```bash
# 添加：所有 95 开头的号码放行
curl -X POST "http://localhost:8098/transfer/numberlist/white/prefix/add?customerAcc=cust001&prefix=95"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/white/prefix/remove?customerAcc=cust001&prefix=95"
```

##### 检查名单

```bash
curl "http://localhost:8098/transfer/numberlist/black/check?customerAcc=cust001&calledNumber=10086"
curl "http://localhost:8098/transfer/numberlist/white/check?customerAcc=cust001&calledNumber=10010"
```

---

### 3.4 禁止呼出时段

配置哪些时间段禁止呼出。数据存储在 DB + Redis。

#### 添加时段

```bash
curl -X POST http://localhost:8098/transfer/forbidden-time/add \
  -H "Content-Type: application/json" \
  -d '{
    "customerAcc": "cust001",
    "periodName": "午休时段",
    "startTime": "12:00:00",
    "endTime": "13:30:00",
    "status": 1
  }'
```

#### 查询时段

```bash
curl "http://localhost:8098/transfer/forbidden-time/list?customerAcc=cust001"
```

#### 分页查询

```bash
curl "http://localhost:8098/transfer/forbidden-time/page?page=1&pageSize=10&customerAcc=cust001&status=1"
```

支持 customerAcc、status 筛选。

#### 删除时段

```bash
curl -X DELETE "http://localhost:8098/transfer/forbidden-time/delete?id=1"
```

#### 同步到 Redis

```bash
# 全量同步
curl -X POST http://localhost:8098/transfer/forbidden-time/sync

# 按客户同步
curl -X POST "http://localhost:8098/transfer/forbidden-time/sync/customer?customerAcc=cust001"
```

**注意**：增删改时段后，必须执行同步操作。

#### 检查当前是否禁止

```bash
curl "http://localhost:8098/transfer/forbidden-time/check?customerAcc=cust001"
```

---

### 3.5 被叫频次控制

纯 Redis 计数器，按客户+被叫号码+小时维度统计。上限取自 `call_customer.max_calls_per_hour`。

#### 查看当前计数

```bash
curl "http://localhost:8098/transfer/freq/count?customerAcc=cust001&calledNumber=13900139000"
```

#### 重置计数

```bash
curl -X POST "http://localhost:8098/transfer/freq/reset?customerAcc=cust001&calledNumber=13900139000"
```

#### 检查并递增

```bash
curl "http://localhost:8098/transfer/freq/check?customerAcc=cust001&calledNumber=13900139000"
```

返回 `true`/`false`，同时执行计数+1。

---

### 3.6 话单查询

话单由 FreeSWITCH mod_format_cdr 自动推送到 `POST /transfer/cdr/receive`，计费和扣费自动完成。

#### 分页查询

```bash
curl "http://localhost:8098/transfer/cdr/page?page=1&pageSize=10&customerAcc=cust001&startTime=2026-04-01&endTime=2026-04-13"
```

| 参数 | 说明 | 取值 |
|------|------|------|
| customerAcc | 客户账号（可选） | 字符串 |
| callerNumber | 主叫号码（可选） | 字符串 |
| destinationNumber | 被叫号码（可选） | 字符串 |
| startTime | 开始时间（可选） | yyyy-MM-dd |
| endTime | 结束时间（可选） | yyyy-MM-dd |
| page | 页码（默认 1） | 整数 |
| pageSize | 每页条数（默认 10） | 整数 |

返回格式：`{data: [], total, page, pageSize}`

#### 按 UUID 查询

```bash
curl "http://localhost:8098/transfer/cdr/uuid/xxx-xxx-xxx"
```

---

## 4. Redis Key 清单

| Key 模式 | 类型 | 说明 | 生命周期 |
|----------|------|------|---------|
| `CALLER_AUTH:{customerAcc}` | Set | 主叫白名单号码集合 | 持久（需手动同步） |
| `CALLER_AUTH_REVERSE:{callerNumber}` | String | 主叫→客户账号反查 | 持久（需手动同步） |
| `CALLED_BLACK_EXACT:{customerAcc}` | Set | 被叫精准黑名单 | DB 同步，启动时自动加载 |
| `CALLED_BLACK_PREFIX:{customerAcc}` | Set | 被叫前缀黑名单 | DB 同步，启动时自动加载 |
| `CALLED_WHITE_EXACT:{customerAcc}` | Set | 被叫精准白名单 | DB 同步，启动时自动加载 |
| `CALLED_WHITE_PREFIX:{customerAcc}` | Set | 被叫前缀白名单 | DB 同步，启动时自动加载 |
| `FORBIDDEN_TIME:{customerAcc}` | Hash | 禁止时段，`period_N`=`HH:mm:ss-HH:mm:ss` | 持久（需手动同步） |
| `CALLED_FREQ:{acc}:{number}:{yyyyMMddHH}` | String(INCR) | 频次计数器 | 3600s 自动过期 |

### 手动清理 Redis

```bash
# 清除某客户的主叫鉴权
redis-cli DEL "CALLER_AUTH:cust001" "CALLER_AUTH_REVERSE:13800138000"

# 清除某客户的黑白名单（清除后通过同步恢复）
redis-cli DEL "CALLED_BLACK_EXACT:cust001" "CALLED_BLACK_PREFIX:cust001"
redis-cli DEL "CALLED_WHITE_EXACT:cust001" "CALLED_WHITE_PREFIX:cust001"

# 清除某客户的时段配置
redis-cli DEL "FORBIDDEN_TIME:cust001"

# 清除某客户的频次计数（需 pattern 匹配）
redis-cli --scan --pattern "CALLED_FREQ:cust001:*" | xargs redis-cli DEL
```

---

## 5. 计费规则

```
费用 = 单价 × 向上取整分钟数
```

| billsec | 分钟数 | 单价 0.10 | 说明 |
|---------|--------|-----------|------|
| 1-60s   | 1      | 0.10      | 不足1分钟按1分钟 |
| 61-120s | 2      | 0.20      | |
| 120s    | 2      | 0.20      | 刚好2分钟 |

### 预付费 vs 后付费

| | 预付费 (payType=0) | 后付费 (payType=1) |
|---|---|---|
| 呼叫前 | 检查余额 > 0，不足则拦截 | 直接放行 |
| 话单后 | 原子扣费，余额不足则跳过 | 只记录计费日志，不扣费 |

---

## 6. 常见问题

### Q1：新增白名单/时段后，呼叫仍被拦截

**原因**：数据未同步到 Redis。

**解决**：
```bash
# 主叫鉴权
curl -X POST "http://localhost:8098/transfer/auth/sync/customer?customerAcc=cust001"

# 时段
curl -X POST "http://localhost:8098/transfer/forbidden-time/sync/customer?customerAcc=cust001"
```

### Q2：话单未入库

**排查步骤**：
1. 检查 FreeSWITCH mod_format_cdr 配置是否指向本服务 `/transfer/cdr/receive`
2. 查看服务日志中有无 `CDR 处理异常`
3. 确认主叫号码能在 `CALLER_AUTH_REVERSE:{caller}` 中查到客户账号

### Q3：预付费客户余额充足但扣费失败

**原因**：并发扣费竞争。原子 SQL `WHERE balance >= fee` 在高并发下只有一个请求成功。

**排查**：
```sql
SELECT balance FROM call_customer WHERE account = 'cust001';
```
确认实际余额。日志中会记录 `CDR 扣费失败: 余额不足`。

### Q4：频次限制误触发

**临时解除**：
```bash
curl -X POST "http://localhost:8098/transfer/freq/reset?customerAcc=cust001&calledNumber=13900139000"
```

**永久调整**：修改该客户的 `max_calls_per_hour`：
```bash
curl -X PUT http://localhost:8098/transfer/customer/update \
  -H "Content-Type: application/json" \
  -d '{"id":1, "account":"cust001", "maxCallsPerHour":200, ...其他字段}'
```

### Q5：服务重启后 Redis 数据丢失

**解决**：重新同步 DB 数据到 Redis：
```bash
curl -X POST http://localhost:8098/transfer/auth/sync
curl -X POST http://localhost:8098/transfer/forbidden-time/sync
curl -X POST http://localhost:8098/transfer/numberlist/sync
```

> 注意：服务启动时会自动执行上述三个同步，通常无需手动操作。仅当自动同步后仍有问题时手动执行。

频次计数为纯 Redis 数据，无 DB 持久化，丢失后会在下次呼叫时自动重建。

### Q6：通过 DB 接口新增的黑白名单未生效

**排查步骤**：
1. 确认记录 `status=1`（启用状态）
2. 确认 `matchType` 正确：1=精确匹配需要完整号码，2=前缀匹配只需要号码前缀
3. 手动触发同步：`curl -X POST "http://localhost:8098/transfer/numberlist/sync/customer?customerAcc=cust001"`
4. 检查 Redis 中对应 Key 是否存在：`redis-cli SMEMBERS "CALLED_BLACK_EXACT:cust001"`

---

## 7. 关键日志关键字

| 关键字 | 说明 |
|--------|------|
| `CDR 计费` | 正常计费，含 customerAcc/billsec/minutes/fee |
| `CDR 扣费` | 预付费扣费完成 |
| `CDR 扣费失败` | 预付费余额不足 |
| `CDR 处理异常` | 话单处理异常，需排查 |
| `Insert FS CDR` | 话单写入完成 |

---

## 8. 数据同步策略总览

| 服务 | 数据源 | 启动自动加载 | 手动同步 |
|------|--------|-------------|---------|
| CallerAuthService | DB + Redis | `@PostConstruct` 全量加载 | `/transfer/auth/sync` |
| ForbiddenTimeService | DB + Redis | `@PostConstruct` 全量加载 | `/transfer/forbidden-time/sync` |
| CalledNumberListService | DB + Redis | `@PostConstruct` 全量加载 | `/transfer/numberlist/sync` |
| CalledFreqService | 纯 Redis | - | 自动 INCR + 过期 |

---

## 9. 接口总览

| 前缀 | 功能 | 接口数 |
|------|------|--------|
| `/transfer/customer` | 客户管理（含分页） | 7 |
| `/transfer/auth` | 主叫鉴权白名单（含分页） | 8 |
| `/transfer/numberlist` | 被叫黑白名单（含 DB 持久化 + 分页） | 16 |
| `/transfer/forbidden-time` | 禁止呼出时段（含分页） | 8 |
| `/transfer/freq` | 被叫频次控制 | 3 |
| `/transfer/cdr` | 话单接收与查询（含分页） | 3 |

完整接口参数详见源码 Controller 或项目 CLAUDE.md。
