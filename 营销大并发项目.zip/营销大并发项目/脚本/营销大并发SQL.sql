--营销大并发SQL


--充值余额
UPDATE freeswitch.call_customer
SET balance = balance + 500.00 
WHERE account = 'cust001';
