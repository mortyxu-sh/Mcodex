#!/bin/bash

# 添加被叫号码黑白名单
URL="http://192.168.10.61:8098/transfer/numberlist/record/add"
CUSTOMER_ACC="xm"  # 修改为你的客户账号
MATCH_TYPE=1       # 匹配类型：1=精确匹配，2=前缀匹配
LIST_TYPE=1        # 列表类型：1=黑名单，2=白名单
STATUS=1           # 状态：0=禁用，1=启用

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查文件是否存在
if [ ! -f "numbers.txt" ]; then
    echo -e "${RED}错误: numbers.txt 文件不存在${NC}"
    echo "请创建 numbers.txt 文件，每行一个号码"
    exit 1
fi

# 计数
SUCCESS=0
FAIL=0
TOTAL=0

echo -e "${YELLOW}开始批量添加黑名单号码...${NC}"
echo "客户账号: $CUSTOMER_ACC"
echo "接口地址: $URL"
echo "=========================="

# 逐行读取文件
while IFS= read -r number || [ -n "$number" ]
do
    # 跳过空行
    if [ -z "$number" ]; then
        continue
    fi
    
    TOTAL=$((TOTAL + 1))
    
    # 构建 JSON 请求体
    json_data=$(cat <<EOF
{
    "customerAcc": "$CUSTOMER_ACC",
    "number": "$number",
    "matchType": $MATCH_TYPE,
    "listType": $LIST_TYPE,
    "status": $STATUS
}
EOF
)
    
    # 发送 POST 请求
    response=$(curl -s -X POST "$URL" \
        -H "Content-Type: application/json" \
        -d "$json_data")
    
    # 检查返回的 JSON 中是否包含 "id" 字段（表示添加成功）
    if echo "$response" | grep -q '"id"'; then
        # 提取 id 值用于显示（可选）
        id=$(echo "$response" | grep -o '"id":[0-9]*' | cut -d':' -f2)
        echo -e "${GREEN}✓ $number - 添加成功 (ID: $id)${NC}"
        SUCCESS=$((SUCCESS + 1))
    else
        echo -e "${RED}✗ $number - 添加失败 (返回: $response)${NC}"
        FAIL=$((FAIL + 1))
    fi
    
    # 添加延迟避免请求过快（可选）
    sleep 0.1
    
done < numbers.txt

# 输出统计
echo "=========================="
echo -e "${YELLOW}批量添加完成！${NC}"
echo "总计: $TOTAL"
echo -e "${GREEN}成功: $SUCCESS${NC}"
echo -e "${RED}失败: $FAIL${NC}"