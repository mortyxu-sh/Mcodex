#!/bin/bash

# 添加主叫白名单
URL="http://192.168.10.61:8098/transfer/auth/add"
CUSTOMER_ACC="xm"  # 修改为你的客户账号
STATUS=1           # 状态：1-启用，0-禁用

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查文件是否存在
if [ ! -f "callers.txt" ]; then
    echo -e "${RED}错误: callers.txt 文件不存在${NC}"
    echo "请创建 callers.txt 文件，每行一个主叫号码"
    exit 1
fi

# 计数
SUCCESS=0
FAIL=0
TOTAL=0

echo -e "${YELLOW}开始批量添加主叫白名单号码...${NC}"
echo "客户账号: $CUSTOMER_ACC"
echo "接口地址: $URL"
echo "=========================="

# 逐行读取文件
while IFS= read -r caller_number || [ -n "$caller_number" ]
do
    # 跳过空行
    if [ -z "$caller_number" ]; then
        continue
    fi
    
    TOTAL=$((TOTAL + 1))
    
    # 构建 JSON 请求体
    json_data=$(cat <<EOF
{
    "customerAcc": "$CUSTOMER_ACC",
    "callerNumber": "$caller_number",
    "status": $STATUS
}
EOF
)
    
    # 发送 POST 请求并获取返回内容
    response=$(curl -s -X POST "$URL" \
        -H "Content-Type: application/json" \
        -d "$json_data")
    
    # 检查返回值是否为 1（添加成功）
    if [ "$response" = "1" ]; then
        echo -e "${GREEN}✓ $caller_number - 添加成功 (返回值: $response)${NC}"
        SUCCESS=$((SUCCESS + 1))
    else
        echo -e "${RED}✗ $caller_number - 添加失败 (返回值: $response)${NC}"
        FAIL=$((FAIL + 1))
    fi
    
    # 添加延迟避免请求过快（可选）
    sleep 0.1
    
done < callers.txt

# 输出统计
echo "=========================="
echo -e "${YELLOW}批量添加完成！${NC}"
echo "总计: $TOTAL"
echo -e "${GREEN}成功: $SUCCESS${NC}"
echo -e "${RED}失败: $FAIL${NC}"

# 根据结果设置退出码
if [ $FAIL -gt 0 ]; then
    exit 1
else
    exit 0
fi