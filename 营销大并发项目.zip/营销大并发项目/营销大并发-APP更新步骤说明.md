## 变更记录
> 记录每次修订的内容，方便追溯。
>

[此处为语雀卡片，点击链接查看](about:blank#jwCdp)

## 背景
记录更新 APP 的步骤方法，可在呼叫负荷不大时操作，不会影响当前呼叫。

## 方法
:::danger
以更新“**<u><font style="color:#DF2A3F;">192.168.10.62</font></u>**”上 APP 为例。

若在业务时间替换务必注意操作细节，多核对。

:::

### 下线需要更新的服务器在 Ningx 的负载
在当前主 Nginx (192.168.10.61)操作

```bash
# 下线Ningx对应负载:注意sed命令内正则匹配对应的IP：此处下线192.168.10.62
sed -i "s/^[^#].*192.168.10.62.*$/#&/g" /usr/local/nginx/conf/nginx.conf /usr/local/nginx/conf/conf.d/yx_cdr_server.conf
# 核对确认2处修改
grep 192.168.10 /usr/local/nginx/conf/conf.d/yx_cdr_server.conf /usr/local/nginx/conf/nginx.conf

# 重载Nginx
/usr/local/nginx/sbin/nginx -s reload
```

### 更新 APP
在对应 APP 服务器操作

```bash
# 切至App目录
cd /home/java
# 停服务
supervisorctl stop esl_server
# 旧APP重命名为ctime后缀
mv fs-esl-springboot-starter-callout-1.0.0.RELEASE.jar "fs-esl-springboot-starter-callout-1.0.0.RELEASE.jar.$(date -d @$(stat -c %Y fs-esl-springboot-starter-callout-1.0.0.RELEASE.jar) +'%Y-%m-%d_%H-%M-%S')"
# 上传新APP
# 可用rz、scp等，上传后可ll命令对比文件大小初步区分是否不同APP

# 启服务
supervisorctl start esl_server
```

### 上线 Nginx 负载
在当前主 Nginx (192.168.10.61)操作

```bash
# 上线负载:注意sed命令内正则匹配对应的IP：此处上线192.168.10.62
sed -i "/^#.*192.168.10.62.*$/s/^#//" /usr/local/nginx/conf/nginx.conf /usr/local/nginx/conf/conf.d/yx_cdr_server.conf
# 核对确认2处修改
grep 192.168.10 /usr/local/nginx/conf/conf.d/yx_cdr_server.conf /usr/local/nginx/conf/nginx.conf

# 重载Nginx
/usr/local/nginx/sbin/nginx -s reload
```

## 总结


## 附件




