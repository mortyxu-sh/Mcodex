# 转接外呼 (Transfer Callout) 运维手册

> 服务端口：8098 | 最后更新：2026-03-21

---

## 1. 功能概述

转接外呼是一个独立呼叫流，通过 FreeSWITCH 拨号计划 `"2000"` 前缀路由触发。呼叫发起前经过 6 步校验管道，任一不通过则拦截呼叫。

### 校验管道

```
主叫鉴权 → 时段控制 → 被叫黑名单 → 被叫白名单(放行跳过后续) → 客户余额 → 被叫频次
```

| 步骤 | 校验项 | 不通过结果码 | 说明 |
|------|--------|-------------|------|
| 1 | 主叫鉴权 | 1 | 主叫号码不在白名单中 |
| 2 | 时段控制 | 2 | 当前时间在禁止呼出时段内 |
| 3 | 被叫黑名单 | 3 | 被叫号码在黑名单中 |
| 4 | 被叫白名单 | 0 | 白名单命中则直接放行，跳过 5-6 |
| 5 | 客户余额 | 4 | 仅预付费客户检查，后付费直接放行 |
| 6 | 被叫频次 | 5 | 超过每小时呼叫上限 |

---

## 2. 部署与启动

### 2.1 建表

首次部署执行建表脚本：

```bash
mysql -u root -p < src/main/resources/sql/init_transfer_callout.sql
```

共 4 张表：`call_customer`、`call_caller_auth`、`call_forbidden_time`、`fs_cdr`。

### 2.2 启动服务

```bash
java -jar fs-esl-springboot-starter-callout-1.0.0.RELEASE.jar
```

启动时自动执行：
- `CallerAuthSyncService` — 从 DB 全量加载主叫鉴权白名单到 Redis
- `ForbiddenTimeSyncService` — 从 DB 全量加载禁止时段到 Redis

### 2.3 依赖

| 组件 | 说明 |
|------|------|
| MySQL | 主从架构，读写分离 |
| Redis | 校验数据缓存 + 频次计数器 |
| FreeSWITCH | ESL 事件源 + mod_format_cdr 话单推送 |

---

## 3. 日常运维操作

### 3.1 客户管理

#### 新增客户

```bash
curl -X POST http://localhost:8098/transfer/customer/add \
  -H "Content-Type: application/json" \
  -d '{
    "account": "cust001",
    "name": "客户A",
    "balance": 1000.00,
    "unitPrice": 0.10,
    "payType": 0,
    "maxCallsPerHour": 100,
    "status": 1
  }'
```

**字段说明**：
| 字段 | 说明 | 取值 |
|------|------|------|
| account | 客户账号（唯一） | 字符串 |
| balance | 余额 | DECIMAL，后付费可设 0 |
| unitPrice | 每分钟单价 | DECIMAL |
| payType | 付费类型 | 0=预付，1=后付 |
| maxCallsPerHour | 每小时最大呼叫次数 | 0=不限制 |
| status | 状态 | 0=禁用，1=启用 | 

#### 查询客户

```bash
curl "http://localhost:8098/transfer/customer/get?account=cust001"
```

#### 客户列表

```bash
curl "http://localhost:8098/transfer/customer/list"
```

#### 更新客户

```bash
curl -X PUT http://localhost:8098/transfer/customer/update \
  -H "Content-Type: application/json" \
  -d '{
    "id": 1,
    "account": "cust001",
    "name": "客户A",
    "balance": 500.00,
    "unitPrice": 0.10,
    "payType": 0,
    "maxCallsPerHour": 100,
    "status": 1
  }'
```

#### 删除客户

```bash
curl -X DELETE "http://localhost:8098/transfer/customer/delete?id=1"
```

#### 检查余额

```bash
curl "http://localhost:8098/transfer/customer/balance?account=cust001"
```

返回 `true`/`false`。后付费客户始终返回 `true`。

#### 充值余额

直接通过 SQL 操作：

```sql
UPDATE call_customer SET balance = balance + 500.00 WHERE account = 'cust001';
```

---

### 3.2 主叫号码鉴权白名单

管理哪些主叫号码可以使用转接外呼功能。数据存储在 DB + Redis。

#### 添加白名单

```bash
curl -X POST http://localhost:8098/transfer/auth/add \
  -H "Content-Type: application/json" \
  -d '{
    "customerAcc": "cust001",
    "callerNumber": "13800138000",
    "status": 1
  }'
```

添加后需手动同步到 Redis（见下方同步操作）。

#### 查询白名单

```bash
curl "http://localhost:8098/transfer/auth/list?customerAcc=cust001"
```

#### 删除白名单

```bash
curl -X DELETE "http://localhost:8098/transfer/auth/delete?id=1"
```

#### 同步到 Redis

```bash
# 全量同步所有客户
curl -X POST http://localhost:8098/transfer/auth/sync

# 按客户同步
curl -X POST "http://localhost:8098/transfer/auth/sync/customer?customerAcc=cust001"
```

**注意**：增删改白名单后，必须执行同步操作，否则 Redis 中数据不会更新。

#### 检查鉴权

```bash
curl "http://localhost:8098/transfer/auth/check?customerAcc=cust001&callerNumber=13800138000"
```

---

### 3.3 被叫号码黑白名单

纯 Redis 存储，无 DB 表。操作即时生效，无需同步。

#### 黑名单 — 精准匹配

```bash
# 添加
curl -X POST "http://localhost:8098/transfer/numberlist/black/exact/add?customerAcc=cust001&number=10086"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/black/exact/remove?customerAcc=cust001&number=10086"
```

#### 黑名单 — 前缀匹配

```bash
# 添加：拦截所有 400 开头的号码
curl -X POST "http://localhost:8098/transfer/numberlist/black/prefix/add?customerAcc=cust001&prefix=400"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/black/prefix/remove?customerAcc=cust001&prefix=400"
```

#### 白名单 — 精准匹配

```bash
# 添加
curl -X POST "http://localhost:8098/transfer/numberlist/white/exact/add?customerAcc=cust001&number=10010"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/white/exact/remove?customerAcc=cust001&number=10010"
```

#### 白名单 — 前缀匹配

```bash
# 添加：所有 95 开头的号码放行
curl -X POST "http://localhost:8098/transfer/numberlist/white/prefix/add?customerAcc=cust001&prefix=95"

# 移除
curl -X DELETE "http://localhost:8098/transfer/numberlist/white/prefix/remove?customerAcc=cust001&prefix=95"
```

#### 检查名单

```bash
curl "http://localhost:8098/transfer/numberlist/black/check?customerAcc=cust001&calledNumber=10086"
curl "http://localhost:8098/transfer/numberlist/white/check?customerAcc=cust001&calledNumber=10010"
```

---

### 3.4 禁止呼出时段

配置哪些时间段禁止呼出。数据存储在 DB + Redis。

#### 添加时段

```bash
curl -X POST http://localhost:8098/transfer/forbidden-time/add \
  -H "Content-Type: application/json" \
  -d '{
    "customerAcc": "cust001",
    "periodName": "午休时段",
    "startTime": "12:00:00",
    "endTime": "13:30:00",
    "status": 1
  }'
```

#### 查询时段

```bash
curl "http://localhost:8098/transfer/forbidden-time/list?customerAcc=cust001"
```

#### 删除时段

```bash
curl -X DELETE "http://localhost:8098/transfer/forbidden-time/delete?id=1"
```

#### 同步到 Redis

```bash
# 全量同步
curl -X POST http://localhost:8098/transfer/forbidden-time/sync

# 按客户同步
curl -X POST "http://localhost:8098/transfer/forbidden-time/sync/customer?customerAcc=cust001"
```

**注意**：增删改时段后，必须执行同步操作。

#### 检查当前是否禁止

```bash
curl "http://localhost:8098/transfer/forbidden-time/check?customerAcc=cust001"
```

---

### 3.5 被叫频次控制

纯 Redis 计数器，按客户+被叫号码+小时维度统计。上限取自 `call_customer.max_calls_per_hour`。

#### 查看当前计数

```bash
curl "http://localhost:8098/transfer/freq/count?customerAcc=cust001&calledNumber=13900139000"
```

#### 重置计数

```bash
curl -X POST "http://localhost:8098/transfer/freq/reset?customerAcc=cust001&calledNumber=13900139000"
```

#### 检查并递增

```bash
curl "http://localhost:8098/transfer/freq/check?customerAcc=cust001&calledNumber=13900139000"
```

返回 `true`/`false`，同时执行计数+1。

---

### 3.6 话单查询

#### 按 UUID 查询

```bash
curl "http://localhost:8098/transfer/cdr/uuid?uuid=xxx-xxx-xxx"
```

#### 按主叫号码查询

```bash
curl "http://localhost:8098/transfer/cdr/caller?callerNumber=13800138000"
```

#### 按被叫号码查询

```bash
curl "http://localhost:8098/transfer/cdr/called?destinationNumber=13900139000"
```

#### 按客户账号查询

```bash
curl "http://localhost:8098/transfer/cdr/customer?customerAcc=cust001"
```

---

## 4. Redis Key 清单

| Key 模式 | 类型 | 说明 | 生命周期 |
|----------|------|------|---------|
| `CALLER_AUTH:{customerAcc}` | Set | 主叫白名单号码集合 | 持久（需手动同步） |
| `CALLER_AUTH_REVERSE:{callerNumber}` | String | 主叫→客户账号反查 | 持久（需手动同步） |
| `CALLED_BLACK_EXACT:{customerAcc}` | Set | 被叫精准黑名单 | API 操作即时 |
| `CALLED_BLACK_PREFIX:{customerAcc}` | Set | 被叫前缀黑名单 | API 操作即时 |
| `CALLED_WHITE_EXACT:{customerAcc}` | Set | 被叫精准白名单 | API 操作即时 |
| `CALLED_WHITE_PREFIX:{customerAcc}` | Set | 被叫前缀白名单 | API 操作即时 |
| `FORBIDDEN_TIME:{customerAcc}` | Hash | 禁止时段，`period_N`=`HH:mm:ss-HH:mm:ss` | 持久（需手动同步） |
| `CALLED_FREQ:{acc}:{number}:{yyyyMMddHH}` | String(INCR) | 频次计数器 | 3600s 自动过期 |

### 手动清理 Redis

```bash
# 清除某客户的主叫鉴权
redis-cli DEL "CALLER_AUTH:cust001" "CALLER_AUTH_REVERSE:13800138000"

# 清除某客户的黑白名单
redis-cli DEL "CALLED_BLACK_EXACT:cust001" "CALLED_BLACK_PREFIX:cust001"
redis-cli DEL "CALLED_WHITE_EXACT:cust001" "CALLED_WHITE_PREFIX:cust001"

# 清除某客户的时段配置
redis-cli DEL "FORBIDDEN_TIME:cust001"

# 清除某客户的频次计数（需 pattern 匹配）
redis-cli --scan --pattern "CALLED_FREQ:cust001:*" | xargs redis-cli DEL
```

---

## 5. 计费规则

```
费用 = 单价 × 向上取整分钟数
```

| billsec | 分钟数 | 单价 0.10 | 说明 |
|---------|--------|-----------|------|
| 1-60s   | 1      | 0.10      | 不足1分钟按1分钟 |
| 61-120s | 2      | 0.20      | |
| 120s    | 2      | 0.20      | 刚好2分钟 |

### 预付费 vs 后付费

| | 预付费 (payType=0) | 后付费 (payType=1) |
|---|---|---|
| 呼叫前 | 检查余额 > 0，不足则拦截 | 直接放行 |
| 话单后 | 原子扣费，余额不足则跳过 | 只记录计费日志，不扣费 |

---

## 6. 常见问题

### Q1：新增白名单/时段后，呼叫仍被拦截

**原因**：数据未同步到 Redis。

**解决**：
```bash
# 主叫鉴权
curl -X POST "http://localhost:8098/transfer/auth/sync/customer?customerAcc=cust001"

# 时段
curl -X POST "http://localhost:8098/transfer/forbidden-time/sync/customer?customerAcc=cust001"
```

### Q2：话单未入库

**排查步骤**：
1. 检查 FreeSWITCH mod_format_cdr 配置是否指向本服务 `/transfer/cdr/receive`
2. 查看服务日志中有无 `CDR 处理异常`
3. 确认主叫号码能在 `CALLER_AUTH_REVERSE:{caller}` 中查到客户账号

### Q3：预付费客户余额充足但扣费失败

**原因**：并发扣费竞争。原子 SQL `WHERE balance >= fee` 在高并发下只有一个请求成功。

**排查**：
```sql
SELECT balance FROM call_customer WHERE account = 'cust001';
```
确认实际余额。日志中会记录 `CDR 扣费失败: 余额不足`。

### Q4：频次限制误触发

**临时解除**：
```bash
curl -X POST "http://localhost:8098/transfer/freq/reset?customerAcc=cust001&calledNumber=13900139000"
```

**永久调整**：修改该客户的 `max_calls_per_hour`：
```bash
curl -X PUT http://localhost:8098/transfer/customer/update \
  -H "Content-Type: application/json" \
  -d '{"id":1, "account":"cust001", "maxCallsPerHour":200, ...其他字段}'
```

### Q5：服务重启后 Redis 数据丢失

**解决**：重新同步 DB 数据到 Redis：
```bash
curl -X POST http://localhost:8098/transfer/auth/sync
curl -X POST http://localhost:8098/transfer/forbidden-time/sync
```

黑白名单和频次计数无 DB 持久化，Redis 丢失后需通过 API 重新添加。

---

## 7. 关键日志关键字

| 关键字 | 说明 |
|--------|------|
| `CDR 计费` | 正常计费，含 customerAcc/billsec/minutes/fee |
| `CDR 扣费` | 预付费扣费完成 |
| `CDR 扣费失败` | 预付费余额不足 |
| `CDR 处理异常` | 话单处理异常，需排查 |
| `Insert FS CDR` | 话单写入完成 |

---

## 8. 接口总览

| 前缀 | 功能 | 接口数 |
|------|------|--------|
| `/transfer/customer` | 客户管理 | 6 |
| `/transfer/auth` | 主叫鉴权白名单 | 7 |
| `/transfer/numberlist` | 被叫黑白名单 | 10 |
| `/transfer/forbidden-time` | 禁止呼出时段 | 7 |
| `/transfer/freq` | 被叫频次控制 | 3 |
| `/transfer/cdr` | 话单接收与查询 | 5 |

完整接口参数详见源码 Controller 或项目 CLAUDE.md。
